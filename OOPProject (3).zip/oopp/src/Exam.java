import java.util.Date;

public class Exam implements Schedulable {
    private String examName;
    private Date examDate;

    public Exam(String examName) {
        this.examName = examName;
    }

    @Override
    public void schedule(Date date) {
        this.examDate = date;
        System.out.println(examName + " exam scheduled on " + date);
    }

    @Override
    public boolean isScheduled() {
        return examDate != null;
    }

    public void displayExamDetails() {
        System.out.println("Exam: " + examName + "\nScheduled on: " + examDate);
    }
}
