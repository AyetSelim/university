public class Workshop extends Event {
    public Workshop(String name, String description) {
        super(name, description);
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Workshop: " + name + "\nDescription: " + description + "\nScheduled on: " + date);
    }
}
