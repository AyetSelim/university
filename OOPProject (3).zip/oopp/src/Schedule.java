import java.util.ArrayList;
import java.util.List;

public class Schedule {
    private List<Course> courses;

    public Schedule() {
        this.courses = new ArrayList<>();
    }

    public void addCourseToSchedule(Course course) {
        courses.add(course);
    }

    public void displaySchedule() {
        System.out.println("Student Schedule:");
        for (Course course : courses) {
            System.out.println(course.getCourseName() + " at " + course.getScheduleTime());
        }
    }
}

