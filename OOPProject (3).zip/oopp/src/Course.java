import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private String courseCode;
    private Professor professor;
    private List<Student> enrolledStudents;
    private int maxCapacity;
    private String scheduleTime;

    public Course(String courseName, String courseCode, Professor professor, int maxCapacity, String scheduleTime) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.professor = professor;
        this.enrolledStudents = new ArrayList<>();
        this.maxCapacity = maxCapacity;
        this.scheduleTime = scheduleTime;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public Professor getProfessor() {
        return professor;
    }

    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void addStudent(Student student) {
        if (enrolledStudents.size() < maxCapacity) {
            enrolledStudents.add(student);
        }
    }

    public void displayCourseInfo() {
        System.out.println("Course: " + courseName + " (" + courseCode + ")");
        System.out.println("Instructor: " + professor.getName());
        System.out.println("Schedule: " + scheduleTime);
        System.out.println("Max Capacity: " + maxCapacity);
        System.out.println("Enrolled Students: " + enrolledStudents.size());
    }
}
