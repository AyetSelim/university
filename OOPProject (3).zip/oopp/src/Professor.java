import java.util.ArrayList;
import java.util.List;

public class Professor extends Person {
    private String department;
    private List<Course> coursesTeaching;

    public Professor(String name, String id, String department) {
        super(name, id);
        this.department = department;
        this.coursesTeaching = new ArrayList<>();
    }

    @Override
    public void displayDetails() {
        System.out.println("Professor Name: " + getName());
        System.out.println("Department: " + department);
        System.out.println("Courses Taught: ");
        for (Course course : coursesTeaching) {
            System.out.println(course.getCourseName());
        }
    }

    public void assignCourse(Course course) {
        coursesTeaching.add(course);
    }

    public void gradeStudent(Student student, Course course, Grade grade) {
        System.out.println("Assigning grade " + grade.getGrade() + " to " + student.getName() + " for course " + course.getCourseName());
        student.addGrade(course, grade);
    }
}

