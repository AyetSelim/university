import java.util.Date;

public abstract class Event implements Schedulable {
    protected String name;
    protected Date date;
    protected String description;

    public Event(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @Override
    public void schedule(Date date) {
        this.date = date;
        System.out.println(name + " scheduled on " + date);
    }

    @Override
    public boolean isScheduled() {
        return date != null;
    }

    public abstract void displayEventDetails();  // Abstract method to display event details
}
