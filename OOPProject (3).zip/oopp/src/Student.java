import java.util.HashMap;
import java.util.Map;

public class Student extends Person {
    private String major;
    private Map<Course, Grade> courseGrades;

    public Student(String name, String id, String major) {
        super(name, id);
        this.major = major;
        this.courseGrades = new HashMap<>();
    }

    @Override
    public void displayDetails() {
        System.out.println("Student Name: " + getName());
        System.out.println("Major: " + major);
        // Display grades for courses
        for (Map.Entry<Course, Grade> entry : courseGrades.entrySet()) {
            System.out.println("Course: " + entry.getKey().getCourseName() + " - Grade: " + entry.getValue().getGrade());
        }
    }

    // Method to register for a course
    public void registerCourse(Course course) {
        System.out.println(getName() + " is registered for " + course.getCourseName());
    }

    // Method to add a grade for a course
    public void addGrade(Course course, Grade grade) {
        courseGrades.put(course, grade);
        System.out.println("Grade for " + course.getCourseName() + " added: " + grade.getGrade());
    }

    // Getters and setters
    public String getMajor() {
        return major;
    }
}
