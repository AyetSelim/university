import java.util.ArrayList;
import java.util.List;

public class Department {
    private String departmentName;
    private List<Course> courses;
    private List<Professor> professors;
    private List<Staff> staffMembers;

    public Department(String departmentName) {
        this.departmentName = departmentName;
        this.courses = new ArrayList<>();
        this.professors = new ArrayList<>();
        this.staffMembers = new ArrayList<>();
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addProfessor(Professor professor) {
        professors.add(professor);
    }

    public void addStaff(Staff staff) {
        staffMembers.add(staff);
    }

    public void displayDepartmentInfo() {
        System.out.println("Department: " + departmentName);
        System.out.println("Courses Offered:");
        for (Course course : courses) {
            System.out.println(course.getCourseName() + " (" + course.getCourseCode() + ")");
        }
    }
}

