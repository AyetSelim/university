abstract class Notification {
    private String message;

    // Constructor to initialize the message
    public Notification(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    // Abstract method to be implemented by subclasses
    public abstract void sendNotification();

    // Method Overloading: Send notification with an additional sender information (e.g., email address, phone number)
    public void sendNotification(String additionalInfo) {
        System.out.println("Sending notification to: " + additionalInfo);
        System.out.println("Message: " + getMessage());
    }
}
