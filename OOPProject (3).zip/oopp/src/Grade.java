public class Grade {
    private String grade;
    private double points;

    public Grade(String grade, double points) {
        this.grade = grade;
        this.points = points;
    }

    public String getGrade() {
        return grade;
    }

    public double getPoints() {
        return points;
    }
}

