class InformationOffice extends UniOffice {

    public InformationOffice(String officeName) {
        super(officeName);
    }

    // Overriding the provideService method to define what this office does
    @Override
    public void provideService() {
        System.out.println("Providing general information at " + getOfficeName());
    }
}