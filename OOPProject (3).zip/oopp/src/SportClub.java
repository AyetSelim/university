class SportClub {
    private String name;

    // Constructor to initialize the name of the sport club
    public SportClub(String name) {
        this.name = name;
    }

    // Method for joining the club
    public void joinClub() {
        System.out.println("Joining the " + name + " sport club.");
    }

    // Getter and setter (optional, if you need it)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
