class Payment {
    private double amount;

    // Constructor to initialize payment amount
    public Payment(double amount) {
        this.amount = amount;
    }

    // Method to process the payment
    public void processPayment() {
        if (amount > 0) {
            System.out.println("Payment of " + amount + " processed successfully.");
        } else {
            System.out.println("Invalid payment amount. Please enter a valid amount.");
        }
    }

    // Getter and setter for amount (optional)
    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
