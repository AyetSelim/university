class Transportation {
    private String serviceName;

    // Constructor to initialize the name of the transportation service
    public Transportation(String serviceName) {
        this.serviceName = serviceName;
    }

    // Method to manage transportation service
    public void manage() {
        System.out.println("Managing the " + serviceName + " transportation service.");
    }

    // Getter and setter (optional)
    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
}
