
class InternationalOffice extends UniOffice {

    public InternationalOffice(String officeName) {
        super(officeName);
    }

    // Overriding the provideService method to define what this office does
    @Override
    public void provideService() {
        System.out.println("Providing assistance to international students at " + getOfficeName());
    }
}
