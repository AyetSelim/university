import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class University {

    // Department Class
    static class Department {
        private String name;
        private List<Course> courses;

        public Department(String name) {
            this.name = name;
            this.courses = new ArrayList<>();
        }

        public String getName() {
            return name;
        }

        public void addCourse(Course course) {
            courses.add(course);
        }

        public List<Course> getCourses() {
            return courses;
        }
    }

    // Professor Class
    static class Professor {
        private String name;
        private String courseId;
        private String departmentName;

        public Professor(String name, String courseId, String departmentName) {
            this.name = name;
            this.courseId = courseId;
            this.departmentName = departmentName;
        }

        public String getName() {
            return name;
        }

        public void assignCourse(Course course) {
            System.out.println(name + " has been assigned to " + course.getName());
        }

        public void gradeStudent(Student student, Course course, Grade grade) {
            System.out.println("Grading " + student.getName() + " for " + course.getName() + ": " + grade.getGradeLetter() + " (" + grade.getGradePoints() + " points)");
        }
    }

    // Course Class
    static class Course {
        private String name;
        private String courseId;
        private Professor professor;
        private int capacity;
        private String schedule;

        public Course(String name, String courseId, Professor professor, int capacity, String schedule) {
            this.name = name;
            this.courseId = courseId;
            this.professor = professor;
            this.capacity = capacity;
            this.schedule = schedule;
        }

        public String getName() {
            return name;
        }

        public String getCourseId() {
            return courseId;
        }

        public Professor getProfessor() {
            return professor;
        }

        public int getCapacity() {
            return capacity;
        }

        public String getSchedule() {
            return schedule;
        }

        public void setCapacity(int capacity) {
            this.capacity = capacity;
        }
    }

    // Student Class
    static class Student {
        private String name;
        private String studentId;
        private String departmentName;

        public Student(String name, String studentId, String departmentName) {
            this.name = name;
            this.studentId = studentId;
            this.departmentName = departmentName;
        }

        public String getName() {
            return name;
        }

        public String getStudentId() {
            return studentId;
        }

        public String getDepartmentName() {
            return departmentName;
        }
    }

    // Registration Class
    static class Registration {
        public static void registerStudentForCourse(Student student, Course course) throws CourseFullException {
            if (course.getCapacity() <= 0) {
                throw new CourseFullException("The course " + course.getName() + " is full.");
            }
            // Reduce capacity and assume student registered successfully
            course.setCapacity(course.getCapacity() - 1);
            System.out.println(student.getName() + " has been successfully registered for " + course.getName());
        }
    }

    // Schedule Class
    static class Schedule {
        private List<Course> courses;

        public Schedule() {
            this.courses = new ArrayList<>();
        }

        public void addCourseToSchedule(Course course) {
            courses.add(course);
        }

        public void displaySchedule() {
            System.out.println("Student Schedule:");
            for (Course course : courses) {
                System.out.println(course.getName() + " - " + course.getSchedule());
            }
        }
    }

    // Grade Class
    static class Grade {
        private String gradeLetter;
        private double gradePoints;

        public Grade(String gradeLetter, double gradePoints) {
            this.gradeLetter = gradeLetter;
            this.gradePoints = gradePoints;
        }

        public String getGradeLetter() {
            return gradeLetter;
        }

        public double getGradePoints() {
            return gradePoints;
        }
    }

    // Transcript Class
    static class Transcript {
        private List<Grade> grades;

        public Transcript() {
            grades = new ArrayList<>();
        }

        public void addGrade(Grade grade) {
            grades.add(grade);
        }

        public void displayTranscript() {
            System.out.println("Student Transcript:");
            for (Grade grade : grades) {
                System.out.println("Grade: " + grade.getGradeLetter() + " - " + grade.getGradePoints() + " points");
            }
        }
    }

    // CourseFullException Class
    static class CourseFullException extends Exception {
        public CourseFullException(String message) {
            super(message);
        }
    }

    // Book Class (for Library)
    static class Book {
        private String title;
        private String author;
        private boolean isAvailable;

        public Book(String title, String author) {
            this.title = title;
            this.author = author;
            this.isAvailable = true;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public boolean isAvailable() {
            return isAvailable;
        }

        public void borrowBook() {
            if (isAvailable) {
                isAvailable = false;
                System.out.println("You have borrowed " + title);
            } else {
                System.out.println("Sorry, " + title + " is currently unavailable.");
            }
        }

        public void returnBook() {
            isAvailable = true;
            System.out.println("You have returned " + title);
        }
    }

    // Library Class
    static class Library {
        private List<Book> books;

        public Library() {
            books = new ArrayList<>();
        }

        public void addBook(Book book) {
            books.add(book);
        }

        public void displayBooks() {
            System.out.println("\nLibrary Books:");
            for (Book book : books) {
                System.out.println(book.getTitle() + " by " + book.getAuthor() + (book.isAvailable() ? " - Available" : " - Not Available"));
            }
        }

        public void borrowBook(String title) {
            for (Book book : books) {
                if (book.getTitle().equalsIgnoreCase(title)) {
                    book.borrowBook();
                    return;
                }
            }
            System.out.println("Book not found.");
        }

        public void returnBook(String title) {
            for (Book book : books) {
                if (book.getTitle().equalsIgnoreCase(title)) {
                    book.returnBook();
                    return;
                }
            }
            System.out.println("Book not found.");
        }
    }

    // Event Class (Represents University Events)
    static class Event {
        private String eventName;
        private String date;
        private String location;

        public Event(String eventName, String date, String location) {
            this.eventName = eventName;
            this.date = date;
            this.location = location;
        }

        public String getEventName() {
            return eventName;
        }

        public String getDate() {
            return date;
        }

        public String getLocation() {
            return location;
        }

        public void displayEventDetails() {
            System.out.println("Event: " + eventName);
            System.out.println("Date: " + date);
            System.out.println("Location: " + location);
        }
    }

    // Workshop Class (Extends Event)
    static class Workshop extends Event {
        private String instructor;

        public Workshop(String eventName, String date, String location, String instructor) {
            super(eventName, date, location);
            this.instructor = instructor;
        }

        @Override
        public void displayEventDetails() {
            super.displayEventDetails();
            System.out.println("Instructor: " + instructor);
        }
    }

    // Student Club Class
    static class StudentClub {
        private String clubName;
        private List<Student> members;

        public StudentClub(String clubName) {
            this.clubName = clubName;
            this.members = new ArrayList<>();
        }

        public String getClubName() {
            return clubName;
        }

        public void addMember(Student student) {
            members.add(student);
            System.out.println(student.getName() + " has joined the " + clubName + " club.");
        }

        public void displayClubMembers() {
            System.out.println("Members of " + clubName + " club:");
            for (Student member : members) {
                System.out.println(member.getName());
            }
        }
    }

    // Event Manager Class
    static class EventManager {
        private List<Event> events;

        public EventManager() {
            this.events = new ArrayList<>();
        }

        public void addEvent(Event event) {
            events.add(event);
        }

        public void displayAllEvents() {
            System.out.println("\nUpcoming University Events:");
            for (Event event : events) {
                event.displayEventDetails();
                System.out.println();
            }
        }

        // Base interface for services that can be managed
        interface Manageable {
            void manage();
        }

        // Abstract UniOffice class (base class for all university offices)
        abstract class UniOffice {
            private String officeName;

            public UniOffice(String officeName) {
                this.officeName = officeName;
            }

            public String getOfficeName() {
                return officeName;
            }

            // Abstract method to provide service for the university office
            public abstract void provideService();
        }

        // Subclass for International Office
        class InternationalOffice extends UniOffice {
            public InternationalOffice(String officeName) {
                super(officeName);
            }

            @Override
            public void provideService() {
                System.out.println("Providing assistance to international students at " + getOfficeName());
            }
        }

        // Subclass for Information Office
        class InformationOffice extends UniOffice {
            public InformationOffice(String officeName) {
                super(officeName);
            }

            @Override
            public void provideService() {
                System.out.println("Providing general information at " + getOfficeName());
            }
        }

        // Scholarship class to represent scholarships
        class Scholarship {
            private String name;
            private double amount;

            public Scholarship(String name, double amount) {
                this.name = name;
                this.amount = amount;
            }

            public void grantScholarship() {
                System.out.println("Granting " + name + " scholarship of amount: " + amount);
            }
        }

        // SportClub class to represent sport clubs
        class SportClub {
            private String clubName;

            public SportClub(String clubName) {
                this.clubName = clubName;
            }

            public void joinClub() {
                System.out.println("Joining the " + clubName + " sports club.");
            }
        }

        // Payment class to handle student payments
        class Payment {
            private double amount;

            public Payment(double amount) {
                this.amount = amount;
            }

            public void processPayment() {
                System.out.println("Processing payment of amount: " + amount);
            }
        }

        // Hostel class to assign rooms to students
        class Hostel {
            private String hostelName;

            public Hostel(String hostelName) {
                this.hostelName = hostelName;
            }

            public void assignRoom() {
                System.out.println("Assigning a room at " + hostelName);
            }
        }

        // Notification class for sending messages
        abstract class Notification {
            private String message;

            public Notification(String message) {
                this.message = message;
            }

            public String getMessage() {
                return message;
            }

            // Abstract method to be implemented for sending the notification
            public abstract void sendNotification();
        }

        // Notification subclass to send email notifications
        class EmailNotification extends Notification {
            public EmailNotification(String message) {
                super(message);
            }

            @Override
            public void sendNotification() {
                System.out.println("Sending email notification: " + getMessage());
            }
        }

        // Transportation class implementing Manageable interface
        class Transportation implements Manageable {
            private String serviceName;

            public Transportation(String serviceName) {
                this.serviceName = serviceName;
            }

            @Override
            public void manage() {
                System.out.println("Managing transportation service: " + serviceName);
            }
        }

    }


    // Main Method
    public static void main(String[] args) {
        // Create departments, courses, professors, and students
        Department computerScienceDepartment = new Department("Computer Science");

        // Create professors
        Professor profSmith = new Professor("Dr. Smith", "CS101", "Computer Science");

        // Create courses
        Course javaCourse = new Course("Java Programming", "CS101", profSmith, 30, "MWF 10:00-11:00");

        // Register professors for courses
        profSmith.assignCourse(javaCourse);

        // Create students
        Student johnDoe = new Student("John Doe", "S123", "Computer Science");
        Student janeDoe = new Student("Jane Doe", "S124", "Computer Science");

        // Add courses to department
        computerScienceDepartment.addCourse(javaCourse);

        // List of students to simulate the user choosing from
        List<Student> students = new ArrayList<>();
        students.add(johnDoe);
        students.add(janeDoe);

        // Create library and books
        Library library = new Library();
        library.addBook(new Book("Data Structures", "Author A"));
        library.addBook(new Book("Algorithms", "Author B"));

        // Create events and workshops
        EventManager eventManager = new EventManager();
        Event seminar = new Event("Seminar on AI", "2025-02-20", "Room 101");
        Workshop workshop = new Workshop("Java Programming Workshop", "2025-03-15", "Room 102", "Prof. Smith");
        eventManager.addEvent(seminar);
        eventManager.addEvent(workshop);

        // Start the main menu loop
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        List<UniOffice> uniOffices = new ArrayList<>();
        List<Scholarship> scholarships = new ArrayList<>();
        List<SportClub> sportClubs = new ArrayList<>();
        List<Payment> payments = new ArrayList<>();
        List<Transportation> transports = new ArrayList<>();
        List<Hostel> hostels = new ArrayList<>();
        List<Notification> notifications = new ArrayList<>();

        // Creating some default data
        uniOffices.add(new InternationalOffice("International Office"));
        uniOffices.add(new InformationOffice("Information Office"));

        scholarships.add(new Scholarship("Merit Scholarship", 1500.00));
        sportClubs.add(new SportClub("Football Club"));
        payments.add(new Payment(500.00));
        transports.add(new Transportation("Bus Service"));
        hostels.add(new Hostel("Greenwood Hostel", 100));
        while (running) {
            System.out.println("\n*** University Management System ***");
            System.out.println("1. Register Student for Course");
            System.out.println("2. View Student Schedule");
            System.out.println("3. Assign Grade to Student");
            System.out.println("4. View Student Transcript");
            System.out.println("5. View Library Books");
            System.out.println("6. Borrow Book");
            System.out.println("7. Return Book");
            System.out.println("8. View All University Events");
            System.out.println("9. View University Offices");
            System.out.println("10. Grant Scholarship");
            System.out.println("11. Join Sport Club");
            System.out.println("12. Process Payment");
            System.out.println("13. Assign Hostel Room");
            System.out.println("14. Manage Transportation");
            System.out.println("15. Send Notification");
            System.out.println("16. Exit");
            System.out.print("Enter your choice (1-16): ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    // Register Student for Course
                    System.out.println("\nSelect a student to register:");
                    for (int i = 0; i < students.size(); i++) {
                        System.out.println((i + 1) + ". " + students.get(i).getName());
                    }
                    System.out.print("Enter student number: ");
                    int studentIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Consume the newline
                    Student selectedStudent = students.get(studentIndex);

                    // Register for course
                    try {
                        Registration.registerStudentForCourse(selectedStudent, javaCourse);
                    } catch (CourseFullException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    // View Student Schedule
                    System.out.println("\nSelect a student to view their schedule:");
                    for (int i = 0; i < students.size(); i++) {
                        System.out.println((i + 1) + ". " + students.get(i).getName());
                    }
                    System.out.print("Enter student number: ");
                    studentIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Consume the newline
                    selectedStudent = students.get(studentIndex);

                    // Display schedule
                    Schedule studentSchedule = new Schedule();
                    studentSchedule.addCourseToSchedule(javaCourse);
                    studentSchedule.displaySchedule();
                    break;
                case 3:
                    // Assign Grade to Student
                    System.out.println("\nSelect a student to assign a grade:");
                    for (int i = 0; i < students.size(); i++) {
                        System.out.println((i + 1) + ". " + students.get(i).getName());
                    }
                    System.out.print("Enter student number: ");
                    studentIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Consume the newline
                    selectedStudent = students.get(studentIndex);

                    // Assign grade
                    System.out.println("Enter grade for the student (e.g., A, B, C): ");
                    String gradeStr = scanner.nextLine();
                    System.out.println("Enter grade points (e.g., 4.0, 3.5, 2.0): ");
                    double gradePoints = scanner.nextDouble();
                    Grade grade = new Grade(gradeStr, gradePoints);

                    profSmith.gradeStudent(selectedStudent, javaCourse, grade);
                    break;
                case 4:
                    // View Student Transcript
                    System.out.println("\nSelect a student to view their transcript:");
                    for (int i = 0; i < students.size(); i++) {
                        System.out.println((i + 1) + ". " + students.get(i).getName());
                    }
                    System.out.print("Enter student number: ");
                    studentIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Consume the newline
                    selectedStudent = students.get(studentIndex);

                    // Display transcript
                    Transcript studentTranscript = new Transcript();
                    studentTranscript.addGrade(new Grade("A", 4.0)); // Example, you could extend this to fetch from the student
                    studentTranscript.displayTranscript();
                    break;
                case 5:
                    // View Library Books
                    library.displayBooks();
                    break;
                case 6:
                    // Borrow Book
                    System.out.println("Enter the title of the book to borrow: ");
                    String borrowTitle = scanner.nextLine();
                    library.borrowBook(borrowTitle);
                    break;
                case 7:
                    // Return Book
                    System.out.println("Enter the title of the book to return: ");
                    String returnTitle = scanner.nextLine();
                    library.returnBook(returnTitle);
                    break;
                case 8:
                    // View All University Events
                    eventManager.displayAllEvents();
                    break;
                case 9:
                    System.out.println("\nAvailable University Offices:");
                    for (UniOffice office : uniOffices) {
                        office.provideService(); // Polymorphism: Calls overridden method
                    }
                    break;
                case 10:
                    System.out.println("\nEnter scholarship name: ");
                    String scholarshipName = scanner.nextLine();
                    System.out.println("Enter scholarship amount: ");
                    double scholarshipAmount = scanner.nextDouble();
                    scholarships.add(new Scholarship(scholarshipName, scholarshipAmount));
                    System.out.println("Scholarship added: " + scholarshipName + " - Amount: " + scholarshipAmount);
                    break;
                case 11:
                    System.out.println("\nAvailable Sport Clubs:");
                    for (SportClub club : sportClubs) {
                        System.out.println(club.getName());
                    }
                    System.out.println("Enter the name of the new sport club: ");
                    String clubName = scanner.nextLine();
                    SportClub newClub = new SportClub(clubName);
                    sportClubs.add(newClub);
                    System.out.println("You have joined the " + newClub.getName() + " sport club.");
                    break;
                case 12:
                    // Process Payment
                    System.out.print("\nEnter payment amount: ");
                    double amount = scanner.nextDouble();
                    Payment payment = new Payment(amount);
                    payment.processPayment();  // Process the payment
                    payments.add(payment);  // Add payment to the list
                    break;
                case 13:
                    // Assign Hostel Room
                    System.out.println("\nEnter the hostel name: ");
                    String hostelName = scanner.nextLine();
                    System.out.println("Enter the room number: ");
                    int roomNumber = scanner.nextInt();
                    Hostel hostel = new Hostel(hostelName, roomNumber);
                    hostels.add(hostel);
                    System.out.println("Room " + roomNumber + " assigned in " + hostelName);
                    break;
                case 14:
                    // Manage Transportation
                    System.out.println("\nEnter the transportation service name: ");
                    String serviceName = scanner.nextLine();
                    Transportation transport = new Transportation(serviceName);
                    transports.add(transport);
                    transport.manage();  // Manage the transportation service
                    break;
                case 15:
                    // Send Notification
                    System.out.println("\nEnter the notification message: ");
                    String message = scanner.nextLine();
                    notifications.add(new Notification(message) {
                        @Override
                        public void sendNotification() {
                            System.out.println("Sending notification: " + getMessage());
                        }
                    });
                    System.out.println("Notification added.");
                    break;
                case 16:
                    // Exit
                    System.out.println("Exiting the system...");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 16.");
            }
        }

        scanner.close(); // Close the scanner to avoid resource leaks
    }
}

