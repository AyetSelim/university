public class Registration {
    public static void registerStudentForCourse(Student student, Course course) throws CourseFullException {
        if (course.getEnrolledStudents().size() >= course.getMaxCapacity()) {
            throw new CourseFullException("Course " + course.getCourseName() + " is full. Cannot register student.");
        }
        student.registerCourse(course);
        course.addStudent(student);
        System.out.println(student.getName() + " has been successfully registered for " + course.getCourseName());
    }
}
