import java.util.ArrayList;
import java.util.List;

public class StudentClub {
    private String clubName;
    private List<Student> members;

    public StudentClub(String clubName) {
        this.clubName = clubName;
        this.members = new ArrayList<>();
    }

    public void addMember(Student student) {
        members.add(student);
    }

    public void listMembers() {
        System.out.println("Members of " + clubName + ":");
        for (Student member : members) {
            System.out.println("- " + member.getName());
        }
    }
}
