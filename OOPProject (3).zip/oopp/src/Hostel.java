class Hostel {
    private String hostelName;
    private int numberOfRooms;  // Additional field for number of rooms

    // Constructor now requires two arguments
    public Hostel(String hostelName, int numberOfRooms) {
        this.hostelName = hostelName;
        this.numberOfRooms = numberOfRooms;
    }

    public void assignRoom() {
        System.out.println("Assigning a room at " + hostelName + " with " + numberOfRooms + " rooms.");
    }
}
