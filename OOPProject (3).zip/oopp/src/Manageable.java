// The Manageable interface defines common management actions
public interface Manageable {
    void manage();  // Method that will be implemented by the classes
}
