public class Staff extends Person {
    private String role;

    public Staff(String name, String id, String role) {
        super(name, id);
        this.role = role;
    }

    @Override
    public void displayDetails() {
        System.out.println("Staff Name: " + getName());
        System.out.println("Role: " + role);
    }
}


