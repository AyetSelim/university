import java.util.ArrayList;
import java.util.List;

public class Transcript {
    private List<Grade> grades;

    public Transcript() {
        this.grades = new ArrayList<>();
    }

    public void addGrade(Grade grade) {
        grades.add(grade);
    }

    public void displayTranscript() {
        System.out.println("Transcript:");
        for (Grade grade : grades) {
            System.out.println("Grade: " + grade.getGrade() + " Points: " + grade.getPoints());
        }
    }
}
