class Scholarship {
    private String name;
    private double amount;

    // Constructor to initialize name and amount of the scholarship
    public Scholarship(String name, double amount) {
        this.name = name;
        this.amount = amount;
    }

    // Method to grant the scholarship
    public void grantScholarship() {
        System.out.println("Granting " + name + " scholarship of amount: " + amount);
    }

    // Getters and Setters (optional, if needed)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
