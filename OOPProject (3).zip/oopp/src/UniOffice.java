// Abstract base class to represent any university office
abstract class UniOffice {
    private String officeName;

    public UniOffice(String officeName) {
        this.officeName = officeName;
    }

    public String getOfficeName() {
        return officeName;
    }

    // Abstract method for providing service (can be different based on office type)
    public abstract void provideService();
}
