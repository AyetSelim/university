import java.util.Date;

public interface Schedulable {
    void schedule(Date date);  // Schedules the event, exam, or classroom.
    boolean isScheduled();  // Checks if the event, exam, or classroom is scheduled.
}
