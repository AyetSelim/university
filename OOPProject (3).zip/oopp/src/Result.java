public class Result {
    private Exam exam;
    private double score;

    public Result(Exam exam, double score) {
        this.exam = exam;
        this.score = score;
    }

    public void displayResult() {
        System.out.println("Exam: " + exam + "\nScore: " + score);
    }

    public String getGrade() {
        if (score >= 90) {
            return "A";
        } else if (score >= 80) {
            return "B";
        } else if (score >= 70) {
            return "C";
        } else {
            return "F";
        }
    }
}
