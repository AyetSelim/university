import java.util.Date;

public class Classroom implements Schedulable {
    private String roomNumber;
    private Date scheduledDate;

    public Classroom(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public void schedule(Date date) {
        this.scheduledDate = date;
        System.out.println("Classroom " + roomNumber + " scheduled on " + date);
    }

    @Override
    public boolean isScheduled() {
        return scheduledDate != null;
    }

    public void displayClassroomDetails() {
        System.out.println("Classroom: " + roomNumber + "\nScheduled on: " + scheduledDate);
    }
}
